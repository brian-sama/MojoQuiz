import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key';

export interface AuthRequest extends Request {
    user?: {
        userId: string;
        role: string;
    };
}

/**
 * Middleware to authenticate and authorize roles
 * @param allowedRoles Array of roles that can access the route
 */
export const authorize = (allowedRoles: string[] = []) => {
    return (req: AuthRequest, res: Response, next: NextFunction) => {
        try {
            const authHeader = req.headers.authorization;
            if (!authHeader?.startsWith('Bearer ')) {
                return res.status(401).json({ error: 'Authorization required' });
            }

            const token = authHeader.split(' ')[1];
            const decoded = jwt.verify(token, JWT_SECRET) as { userId: string; role: string };

            req.user = decoded;

            if (allowedRoles.length > 0 && !allowedRoles.includes(decoded.role)) {
                // Hierarchical checks? e.g. Admin can do everything a Presenter can
                const roleHierarchy: Record<string, number> = {
                    'admin': 3,
                    'presenter': 2,
                    'user': 1
                };

                const userLevel = roleHierarchy[decoded.role] || 0;
                const requiredLevel = Math.max(...allowedRoles.map(r => roleHierarchy[r] || 0));

                if (userLevel < requiredLevel) {
                    return res.status(403).json({ error: 'Insufficient permissions' });
                }
            }

            next();
        } catch (error) {
            if (error instanceof jwt.TokenExpiredError) {
                return res.status(401).json({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
            }
            return res.status(401).json({ error: 'Invalid token' });
        }
    };
};
