import db from './database.js';
import logger from '../utils/logger.js';

export interface EngagementMetrics {
    totalScore: number;
    accuracyRate: number;
    averageResponseTimeMs: number;
    participationRate: number;
}

export class EngagementService {
    /**
     * Calculate engagement score for a participant in a session
     * Formula: (Accuracy * 0.4) + (SpeedScore * 0.3) + (Creativity * 0.3)
     */
    static calculateScore(isCorrect: boolean | null, responseTimeMs: number | null): number {
        let score = 0;

        // 1. Accuracy (Max 40 points)
        if (isCorrect === true) {
            score += 40;
        }

        // 2. Speed (Max 30 points)
        // Assume < 2 seconds is max speed, > 10 seconds is min speed
        if (responseTimeMs !== null) {
            const speedFactor = Math.max(0, Math.min(1, (10000 - responseTimeMs) / 8000));
            score += Math.round(speedFactor * 30);
        }

        return score;
    }

    /**
     * Aggregate session analytics
     */
    static async getSessionAnalytics(sessionId: string) {
        try {
            const stats = await db.getSessionStats(sessionId);
            const results = await db.getSessionVoteResults(sessionId);

            // Calculate engagement drop-off (mock logic for now)
            // In a real scenario, we'd look at response counts per question over time

            return {
                sessionId,
                totalParticipants: stats.participant_count,
                averageScore: stats.avg_score,
                questionStats: results,
                generatedAt: new Date().toISOString()
            };
        } catch (error) {
            logger.error(`Error calculating session analytics for ${sessionId}:`, error);
            throw error;
        }
    }

    /**
     * Process brainstorming creativity (Point 16.1)
     * Rewards participants based on votes received for their ideas
     */
    static calculateCreativityScore(votesReceived: number): number {
        // 5 points per vote, capped at 30 points
        return Math.min(30, votesReceived * 5);
    }
}
