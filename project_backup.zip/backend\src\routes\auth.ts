import express, { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import db from '../services/database.js';
import { TokenService } from '../services/TokenService.js';
import { emailService } from '../services/emailService.js';
import { sanitizeInput } from '../utils/helpers.js';
import { authorize, AuthRequest } from '../middleware/rbac.js';

const router: Router = express.Router();

const REFRESH_TOKEN_COOKIE_NAME = 'refreshToken';

/**
 * Register
 */
router.post('/register', async (req: Request, res: Response) => {
    try {
        const { email, password, displayName } = req.body;
        if (!email) return res.status(400).json({ error: 'Email is required' });

        const existingUser = await db.getUserByEmail(email);
        if (existingUser) return res.status(400).json({ error: 'User already exists' });

        if (!password || !displayName) {
            return res.status(200).json({ message: 'New user check successful', requiresSetup: true });
        }

        const passwordHash = await bcrypt.hash(password, 12); // Increased rounds to 12
        const name = sanitizeInput(displayName);

        const user = await db.createUser({
            email: email.toLowerCase(),
            password_hash: passwordHash,
            display_name: name,
            auth_provider: 'email',
            is_verified: true,
            role: 'user'
        });

        const accessToken = TokenService.generateAccessToken(user.id, user.role);
        const refreshToken = await TokenService.generateRefreshToken(user.id);

        res.cookie(REFRESH_TOKEN_COOKIE_NAME, refreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
        });

        res.json({
            accessToken,
            user: {
                id: user.id,
                email: user.email,
                displayName: user.display_name,
                role: user.role
            }
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Failed to create account' });
    }
});

/**
 * Login
 */
router.post('/login', async (req: Request, res: Response) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

        const user = await db.getUserByEmail(email);
        if (!user || !user.password_hash) return res.status(401).json({ error: 'Invalid credentials' });

        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) return res.status(401).json({ error: 'Invalid credentials' });

        await db.updateUser(user.id, { last_login_at: new Date() });

        const accessToken = TokenService.generateAccessToken(user.id, user.role);
        const refreshToken = await TokenService.generateRefreshToken(user.id);

        res.cookie(REFRESH_TOKEN_COOKIE_NAME, refreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });

        res.json({
            accessToken,
            user: {
                id: user.id,
                email: user.email,
                displayName: user.display_name,
                role: user.role
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Failed to login' });
    }
});

/**
 * Token Refresh
 */
router.post('/refresh', async (req: Request, res: Response) => {
    try {
        const refreshToken = req.cookies[REFRESH_TOKEN_COOKIE_NAME];
        if (!refreshToken) return res.status(401).json({ error: 'Refresh token missing' });

        const { accessToken, refreshToken: newRefreshToken } = await TokenService.rotateTokens(refreshToken);

        res.cookie(REFRESH_TOKEN_COOKIE_NAME, newRefreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });

        res.json({ accessToken });
    } catch (error: any) {
        console.error('Refresh error:', error);
        res.status(401).json({ error: error.message || 'Failed to refresh token' });
    }
});

/**
 * Logout
 */
router.post('/logout', async (req: Request, res: Response) => {
    const refreshToken = req.cookies[REFRESH_TOKEN_COOKIE_NAME];
    if (refreshToken) {
        await TokenService.revokeToken(refreshToken);
    }
    res.clearCookie(REFRESH_TOKEN_COOKIE_NAME);
    res.json({ success: true });
});

/**
 * Forgot Password
 */
router.post('/forgot-password', async (req: Request, res: Response) => {
    try {
        const { email } = req.body;
        if (!email) return res.status(400).json({ error: 'Email is required' });

        const user = await db.getUserByEmail(email);
        if (!user) return res.json({ message: 'If an account exists, a reset code has been sent' });

        const code = Math.floor(100000 + Math.random() * 900000).toString();
        const expiresAt = new Date(Date.now() + 30 * 60 * 1000);

        await db.createAuthToken({
            user_id: user.id,
            email: user.email,
            token_type: 'password_reset',
            code,
            expires_at: expiresAt
        });

        await emailService.sendPasswordReset(email, code);
        res.json({ message: 'If an account exists, a reset code has been sent' });
    } catch (error) {
        console.error('Forgot password error:', error);
        res.status(500).json({ error: 'Failed to process request' });
    }
});

/**
 * Reset Password
 */
router.post('/reset-password', async (req: Request, res: Response) => {
    try {
        const { email, code, newPassword } = req.body;
        if (!email || !code || !newPassword) return res.status(400).json({ error: 'Missing fields' });

        const token = await db.getValidAuthToken(email, code, 'password_reset');
        if (!token) return res.status(400).json({ error: 'Invalid or expired code' });

        const user = await db.getUserByEmail(email);
        if (!user) return res.status(404).json({ error: 'User not found' });

        const passwordHash = await bcrypt.hash(newPassword, 12);
        await db.updateUser(user.id, { password_hash: passwordHash });
        await db.markAuthTokenUsed(token.id);

        res.json({ message: 'Password reset successful' });
    } catch (error) {
        console.error('Reset password error:', error);
        res.status(500).json({ error: 'Failed to reset password' });
    }
});

/**
 * Get Me
 */
router.get('/me', authorize(), async (req: AuthRequest, res: Response) => {
    try {
        const user = await db.getUserById(req.user!.userId);
        if (!user) return res.status(404).json({ error: 'User not found' });

        res.json({
            id: user.id,
            email: user.email,
            displayName: user.display_name,
            avatarUrl: user.avatar_url,
            role: user.role
        });
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
});

export default router;
