import { Request, Response, NextFunction } from 'express';
import logger from '../utils/logger.js';

export const errorHandler = (err: any, req: Request, res: Response, next: NextFunction) => {
    const statusCode = err.status || err.statusCode || 500;
    const message = err.message || 'Internal Server Error';

    // Log the error
    logger.error({
        method: req.method,
        url: req.url,
        status: statusCode,
        message: message,
        stack: process.env.NODE_ENV !== 'production' ? err.stack : undefined,
    }, 'Unhandled error caught by global handler');

    res.status(statusCode).json({
        error: message,
        ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
    });
};
