$files = git ls-files -c -o --exclude-standard
$tempDir = New-Item -ItemType Directory -Path ".\temp_zip_dir" -Force
foreach ($file in $files) {
    if (Test-Path $file -PathType Leaf) {
        $dest = Join-Path $tempDir $file
        $destDir = Split-Path $dest
        if (-not (Test-Path $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }
        Copy-Item $file -Destination $dest -Force
    }
}
Compress-Archive -Path ".\temp_zip_dir\*" -DestinationPath "project_backup.zip" -Force
Remove-Item -Recurse -Force ".\temp_zip_dir"
Write-Host "Created project_backup.zip successfully."
