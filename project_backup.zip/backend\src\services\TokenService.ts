import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import db from './database.js';

const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-key';
const ACCESS_TOKEN_EXPIRY = '15m';
const REFRESH_TOKEN_EXPIRY_DAYS = 7;

export class TokenService {
    /**
     * Generate a new access token
     */
    static generateAccessToken(userId: string, role: string): string {
        return jwt.sign({ userId, role }, JWT_SECRET, { expiresIn: ACCESS_TOKEN_EXPIRY });
    }

    /**
     * Generate and store a new refresh token
     */
    static async generateRefreshToken(userId: string): Promise<string> {
        const token = uuidv4();
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + REFRESH_TOKEN_EXPIRY_DAYS);

        await db.createRefreshToken(userId, token, expiresAt);

        return token;
    }

    /**
     * Rotate tokens: Verify refresh token and return a new pair
     */
    static async rotateTokens(refreshToken: string) {
        const tokenRecord = await db.getRefreshToken(refreshToken);

        if (!tokenRecord || tokenRecord.is_revoked || new Date(tokenRecord.expires_at) < new Date()) {
            if (tokenRecord) {
                // If token is invalid/expired but exists, revoke all tokens for this user for security
                await db.revokeAllUserRefreshTokens(tokenRecord.user_id);
            }
            throw new Error('Invalid or expired refresh token');
        }

        // Revoke the current one (one-time use)
        await db.revokeRefreshToken(refreshToken);

        // Generate new pair
        const accessToken = this.generateAccessToken(tokenRecord.user_id, tokenRecord.user_role);
        const newRefreshToken = await this.generateRefreshToken(tokenRecord.user_id);

        return { accessToken, refreshToken: newRefreshToken };
    }

    /**
     * Revoke a refresh token (Logout)
     */
    static async revokeToken(token: string) {
        await db.revokeRefreshToken(token);
    }
}
